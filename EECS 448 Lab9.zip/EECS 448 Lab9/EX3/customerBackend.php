<?php
echo "<link href='style.css' rel='stylesheet' type='text/css'/>";
  $Quan1= $_POST["3070"];
  $cost1= $Quan1 * 499;

  $Quan2= $_POST["3080"];
  $cost2= $Quan2 * 699;

  $Quan3= $_POST["3090"];
  $cost3= $Quan3 * 1499;

  $total= $cost1 + $cost2 + $cost3 +$ship ;
  $ship = $_POST["shipping"];
  $password =$_POST["password"];

  if ($ship == "0") {
    $shipType = "Free shipping";
  }
  else if ($ship == "50") {
    $shipType = "Express";
  }
  else if ($ship == "5") {
    $shipType = "Standard shipping";
  }

echo "<h>Thanks for Shopping!</h>";
echo "<br></br>";
echo "<br><b>your password: ".$password."<b></br>";
echo "<br></br>";
echo "<b>Here is the receipt</b>";
echo "<table>";

echo "<tr>";
echo "<th></th>";
echo "<th>Quantity</th>";
echo "<th>Cost Per Item</th>";
echo "<th>Sub total</th>";
echo "</tr>";

echo "<tr>";
echo "<th>RTX 3070</th>";
echo "<td>".$Quan1."</td>";
echo "<td>$499</td>";
echo "<td>$".$cost1."</td>";
echo "</tr>";

echo "<tr>";
echo "<th>RTX 3080</th>";
echo "<td>".$Quan2."</td>";
echo "<td>$699</td>";
echo "<td>$".$cost2."</td>";
echo "</tr>";

echo "<tr>";
echo "<th>RTX 3090</th>";
echo "<td>".$Quan3."</td>";
echo "<td>$1499</td>";
echo "<td>$".$cost3."</td>";
echo "</tr>";

echo "<tr>";
echo "<th>Shipping</th>";
echo "<td colspan='2'>".$shipType."</td>";
echo "<td>$".$ship."</td>";
echo "</tr>";
echo "<tr>";
echo "<th colspan='3'>Total Cost</th>";
echo "<th>$".$total."</th>";
echo "</tr>";
echo "</table>";
?>
