
function check()
{
  var RTX3070 = document.getElementsById('3070').value;
  var RTX3080 = document.getElementsById('3080').value;
  var RTX3090 = document.getElementsById('3090').value;
  var username = document.getElementById('username').value;
  var password = document.getElementById('password').value;

  if ( RTX3070 =="" || RTX3080 =="" || RTX3090 =="")
  {
    alert("quantity error");
    return false;
  }

  if ((number(RTX3070) < 0 ) ||(number(RTX3080) < 0 )||(number(RTX3090) < 0 ) )
  {
    alert("quantity error cause negative");
    return false;
  }

  if(username==""){
    alert("username cannot be Empty");
    return false;
  }

  if(username.includes("@"))
  {
    var x = username.split("@");
    var x1 = x[0];
    var x2 = x[1];
    if (x1 ==" ")
    {
      alert("email address not in correct form");
      return false;
    }

    if(x2.includes("."))
    {
      var y = x2.split(".");
      var y1 =y[0];
      var y2 = y[1];
      if(y1==" " || y2==" ")
      {
        alert(" email address not in correct form");
        return false;
      }
    }
    else{
      alert("email address not in correct form");
      return false;
    }
  }
  else{
    alert("email address not in correct form");
    return false;
  }
  var freeShip = document.getElementById("FreeShip")
  var expressShip = document.getElementById("OverNight")
  var normalShip = document.getElementById("ThreeDays")
  if(freeShip.checked == false){
    if(expressShip.checked == false){
      if(normalShip.checked == false){
        alert("Shipping Option must be choosed");
        return false;
      }
    }
  }

  if(password==""){
      alert(" Password cannot be empty");
      return false;
    }
    return true;

}