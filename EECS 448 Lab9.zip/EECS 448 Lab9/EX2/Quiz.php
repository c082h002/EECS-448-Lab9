<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
$Question1 =$_POST["q1"];
$Question2 =$_POST["q2"];
$Question3 =$_POST["q3"];
$Question4 =$_POST["q4"];
$Question5 =$_POST["q5"];
$scr_cnt = 0;

  if ($Question1 == "Washington") {
    $scr_cnt = $scr_cnt + 20;
  }
  if ($Question2 == "10.16") {
    $scr_cnt = $scr_cnt + 20;
  }
  if ($Question3 == "26") {
    $scr_cnt = $scr_cnt + 20;
  }
  if ($Question4 == "7.4") {
    $scr_cnt = $scr_cnt + 20;
  }
  if ($Question5 == "Lawrence") {
    $scr_cnt = $scr_cnt + 20;
  }

echo "Question1:  What was the capital of American?<br>";
echo "You answered: " . $Question1 . "<br>";
echo "Correct answer: Washington<br>";
echo "<br>";

echo "estion2: When iphone 12 is can pre-oreder?<br>";
echo "You answered: " . $Question2 . "<br>";
echo "Correct answer: 10.16<br>";
echo "<br>";

echo "Question3: How many letters in the alphabet?<br>";
echo "You answered: " . $Question3 . "<br>";
echo "Correct answer: 26<br>";
echo "<br>";

echo "Question4: waht is the date of American Independence Day?<br>";
echo "You answered: " . $Question4 . "<br>";
echo "Correct answer: 7.4<br>";
echo "<br>";

echo "Question5: Where is KU canpus located?<br>";
echo "You answered: " . $Question5 . "<br>";
echo "Correct answer: Lawrence<br>";
echo "<br>";

echo "Your score: ".$scr_cnt."<br>";

?>
